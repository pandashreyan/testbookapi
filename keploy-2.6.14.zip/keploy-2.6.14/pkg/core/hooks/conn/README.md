# Connection Package Documentation

This package contains the events that are triggered during the 
ingress call, capturing both the input and output of the user API 
call.