# Proxy Package Documentation

This package includes modules that the `hooks` package utilizes to 
redirect the outgoing calls of the user API. This redirection is 
done with the aim to record or stub the outputs of dependency calls.