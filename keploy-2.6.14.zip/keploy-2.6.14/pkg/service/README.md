# Service Package Documentation

This package focuses on encapsulating core business operations in a 
maintainable and reusable manner. This package calls the `platform` interface methods 
to store the output of the service methods.