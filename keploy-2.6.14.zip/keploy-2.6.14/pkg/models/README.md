# Models Package Documentation

This package defines all the Go structs used for storing the captured data. It is designed as an independent module.