# CMD Package Documentation

In this package, the `root` command and its `subcommands` are defined 
for the CLI. This package, which is called from the main package, utilizes the 
`pkg` services to execute commands.
